import { Outlet, useLocation } from 'react-router-dom'
import './App.css'
import { Footer } from './components/Footer/Footer'
import { Header } from './components/Header/Header'

function App() {
  const location = useLocation()

  return (
    <>
      <Header location={location.key} />
      <Outlet />
      <Footer />
    </>
  )
}

export default App
