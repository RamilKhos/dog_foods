import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import App from './App'
import { Main } from './components/Main/Main'
import { AuthorizationAndRegistrationForms } from './components/AuthorizationAndRegistrationForms/AuthorizationAndRegistrationForms'
import { ProfileForm } from './components/ProfileForm/ProfileForm'

const queryClient = new QueryClient()

const myRouter = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      {
        path: '/',
        element: <Main />,
      },
      {
        path: 'login',
        element: <AuthorizationAndRegistrationForms />,
      },

      {
        path: 'signup',
        element: <AuthorizationAndRegistrationForms />,
      },
      {
        path: 'profile/:userId',
        element: <ProfileForm />,
      },
    ],
  },
])

const root = ReactDOM.createRoot(document.getElementById('root'))
root.render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={myRouter} />
    </QueryClientProvider>
  </React.StrictMode>,
)
