import { SIGN_IN_DATA_KEY_IN_LS } from '../../const_variables/const_variables'
import { HeaderActiveSigIn } from './HeaderActiveSigIn/HeaderActiveSigIn'
import { HeaderNoActiveSigIn } from './HeaderNoActiveSigIn/HeaderNoActiveSigIn'
import stylesHeader from './styles.module.scss'

export function Header() {
  const checkDataInLS = window.localStorage.getItem(SIGN_IN_DATA_KEY_IN_LS)

  return (
    <header className={`${stylesHeader.header}`}>
      <div className="container">
        {checkDataInLS ? <HeaderActiveSigIn /> : <HeaderNoActiveSigIn />}
      </div>
    </header>
  )
}
