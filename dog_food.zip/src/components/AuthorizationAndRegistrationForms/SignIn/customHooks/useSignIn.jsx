import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../../../../API'
import { SIGN_IN_DATA_KEY_IN_LS } from '../../../../const_variables/const_variables'

export function useSignIn() {
  const navigate = useNavigate()
  const [isError, setIsError] = useState(false)

  const queryClient = useQueryClient()

  const { mutate } = useMutation({
    mutationFn: (formPayload) => api.sigIn(
      formPayload.email,
      formPayload.password,
    ).then((response) => {
      if (response.status === 200) return response.json()
      throw response
    }),

    onSuccess: (data) => {
      window.localStorage.setItem(SIGN_IN_DATA_KEY_IN_LS, JSON.stringify(data))
      queryClient.invalidateQueries({ queryKey: ['signIn'] })
      return navigate('/')
    },

    onError: (error) => {
      console.error(error)
      setIsError(true)
    },
  })

  return {
    isError,
    setIsError,
    mutate,
  }
}
