import { useQuery } from '@tanstack/react-query'
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../../../API'
import { SIGN_IN_DATA_KEY_IN_LS } from '../../../const_variables/const_variables'
import { Loader } from '../../Loader/Loader'
import { MainErrorScreen } from '../../MainErrorScreen/MainErrorScreen'
import { MainCard } from './MainCard/MainCard'

export function MainContainer() {
  const navigate = useNavigate()

  const dataInLS = window.localStorage.getItem(SIGN_IN_DATA_KEY_IN_LS)

  useEffect(() => {
    if (!dataInLS) {
      navigate('/login')
    }
  }, [])

  const {
    data, isLoading, isError,
  } = useQuery({
    queryKey: ['products'],
    queryFn: () => api.showAllProduct()
      .then((response) => {
        if (response.status === 200) return response.json()
        throw response
      }),
  })

  if (isLoading) return <Loader />
  if (isError) return <MainErrorScreen />

  return (
    <div className="container m-20px pt-3">
      <div className="row row-cols-1 row-cols-md-4 g-4 mb-5">
        {data.products.map((el) => (
          <MainCard
            // eslint-disable-next-line no-underscore-dangle
            key={el._id}
            name={el.name}
            price={el.price}
            pictures={el.pictures}
            stock={el.stock}
          />
        ))}
      </div>
    </div>
  )
}
