import { MainContainer } from './MainContainer/MainContainer'

export function Main() {
  return (
    <div>
      <MainContainer />
    </div>
  )
}
